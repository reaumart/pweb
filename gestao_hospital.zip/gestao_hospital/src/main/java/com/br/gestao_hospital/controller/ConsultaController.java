package com.br.gestao_hospital.controller;

import com.br.gestao_hospital.model.entity.Consulta;
import com.br.gestao_hospital.model.entity.Medico;
import com.br.gestao_hospital.model.repository.ConsultaRepository;
import com.br.gestao_hospital.model.repository.MedicoRepository;
import com.br.gestao_hospital.model.repository.PacienteRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.time.LocalDateTime;

@Controller
@Transactional
@RequestMapping("consulta")
public class ConsultaController {
    @Autowired
    ConsultaRepository repository;
    @Autowired
    PacienteRepository pacienteRepository;
    @Autowired
    MedicoRepository medicoRepository;

    @GetMapping("/list")
    public ModelAndView listar(ModelMap model) {
        model.addAttribute("consultas", repository.consultas());
        return new ModelAndView("consulta/list");
    }

    @GetMapping("/remove/{id}")
    public ModelAndView remove(@PathVariable("id") Long id){
        repository.remove(id);
        return new ModelAndView("redirect:/consulta/list");
    }

    @GetMapping("/form")
    public ModelAndView form(Consulta consulta, ModelMap model){
        model.addAttribute("consulta",consulta);
        model.addAttribute("pacientes",pacienteRepository.pacientes());
        model.addAttribute("medicos",medicoRepository.medicos());
        return new ModelAndView("consulta/form");
    }

    @PostMapping("/save")
    public ModelAndView save(
            @RequestParam("medicoId") Long medicoId,
            @RequestParam("pacienteId") Long pacienteId,
            @RequestParam("data") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime data,
            @RequestParam("valor") double valor,
            @RequestParam("observacao") String observacao,
            @RequestParam(value = "id", required = false) Long id
    ) {
        Consulta consulta = new Consulta();
        consulta.setId(id);
        consulta.setData(data);
        consulta.setValor(valor);
        consulta.setObservacao(observacao);

        consulta.setMedico(medicoRepository.medico(medicoId));
        consulta.setPaciente(pacienteRepository.paciente(pacienteId));

        repository.save(consulta);
        return new ModelAndView("redirect:/consulta/list");
    }

    @GetMapping("/edit/{id}")
    public ModelAndView edit(@PathVariable("id") Long id, ModelMap model) {
        model.addAttribute("consulta", repository.consulta(id));
        model.addAttribute("pacientes",pacienteRepository.pacientes());
        model.addAttribute("medicos",medicoRepository.medicos());
        return new ModelAndView("consulta/form");
    }


    @PostMapping("/update")
    public ModelAndView update(
            @RequestParam("medicoId") Long medicoId,
            @RequestParam("pacienteId") Long pacienteId,
            @RequestParam("data") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime data,
            @RequestParam("valor") double valor,
            @RequestParam("observacao") String observacao,
            @RequestParam("id") Long id
    ) {
        Consulta consulta = new Consulta();
        consulta.setId(id);
        consulta.setData(data);
        consulta.setValor(valor);
        consulta.setObservacao(observacao);
        consulta.setMedico(medicoRepository.medico(medicoId));
        consulta.setPaciente(pacienteRepository.paciente(pacienteId));

        repository.update(consulta);
        return new ModelAndView("redirect:/consulta/list");
    }

}
