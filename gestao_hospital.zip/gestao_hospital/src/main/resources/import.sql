INSERT INTO medico (nome, crm) VALUES ('Ana Souza', '12345-SP');
INSERT INTO medico (nome, crm) VALUES ('Carlos Lima', '23456-SP');
INSERT INTO medico (nome, crm) VALUES ('Beatriz Silva', '34567-SP');
INSERT INTO medico (nome, crm) VALUES ('João Mendes', '45678-SP');
INSERT INTO medico (nome, crm) VALUES ('Fernanda Costa', '56789-SP');
INSERT INTO paciente (nome, telefone) VALUES ('Mariana Oliveira', '(11) 91234-5678');
INSERT INTO paciente (nome, telefone) VALUES ('Ricardo Gomes', '(21) 99876-5432');
INSERT INTO paciente (nome, telefone) VALUES ('Luciana Costa', '(31) 98765-4321');
INSERT INTO paciente (nome, telefone) VALUES ('Bruno Lima', '(41) 96543-2109');
INSERT INTO paciente (nome, telefone) VALUES ('Fernanda Souza', '(51) 95432-1098');
INSERT INTO consulta (data, valor, observacao, paciente_id, medico_id) VALUES ('2024-05-01 09:00:00', 150.00, 'Consulta de rotina', 1, 1);

INSERT INTO consulta (data, valor, observacao, paciente_id, medico_id) VALUES ('2024-05-03 14:30:00', 200.00, 'Acompanhamento pós-operatório', 2, 2);

INSERT INTO consulta (data, valor, observacao, paciente_id, medico_id) VALUES ('2024-05-05 11:15:00', 180.00, 'Exame de retorno', 3, 3);

INSERT INTO consulta (data, valor, observacao, paciente_id, medico_id) VALUES ('2024-05-08 08:45:00', 220.00, 'Dor nas costas', 4, 4);

INSERT INTO consulta (data, valor, observacao, paciente_id, medico_id) VALUES ('2024-05-10 10:00:00', 160.00, 'Queixa de tontura', 5, 5);
