package com.br.gestao_hospital;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestaoHospitalApplicationTests {

	@Test
	void contextLoads() {
	}

}
